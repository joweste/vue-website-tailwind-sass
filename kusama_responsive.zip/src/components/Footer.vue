<template>
  <div class="text-center my-12">
    <p class="text-center text-xs text-white font-bold mt-6 mx-auto">
      © 2021 Kusama · Privacy Policy · Terms and Conditions · Cookie Settings
    </p>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
